#ifndef __SHOW_H
#define __SHOW_H	

#include "sys.h"

#include "oled.h"
#include "key.h"
#include "menu.h"
#include "ds18b20.h"
#include "rtc.h"
//#inlcude "key.h"

void Show_HomePage(void);
void Show_OkPage(void);
void Show_SendingPage(void);


#endif 
