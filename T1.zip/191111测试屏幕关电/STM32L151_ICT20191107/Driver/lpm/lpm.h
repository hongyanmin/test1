#ifndef __LPM_H
#define __LPM_H 

#include "stm32l1xx.h"			   
#include "core_cm3.h"
#include "general_type.h"
#include "stm32l1xx_pwr.h"
#include "stm32l1xx_rcc.h"


void Run_Mode(void);
void Stop_Mode(void);
#endif






























