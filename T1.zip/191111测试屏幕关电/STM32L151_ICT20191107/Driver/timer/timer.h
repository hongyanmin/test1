#ifndef _timer_H
#define _timer_H
#include "delay.h"
#include "sys.h"

void TIM2_Init(u16 arr,u16 psc);
void TIM9_Init(u16 arr,u16 psc);
void TIM10_Init(u16 arr,u16 psc);
#endif

